function addpaths()
%ADDPATHS path configuration for TraFlow and MMFVPDES
%   ADDPATHS adds the necessary directories relative to the current
%   directory to the matlab-searchpath (at the front).
%
%   Make sure to call this routine from the 'traflowpack' root-dir.

% Copyright (C) 2002 Arthur van Dam, Delft, The Netherlands
% 
% This file is part of TraFlowPACK.
% 
% TraFlowPACK is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
% 
% TraFlowPACK is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with TraFlowPACK; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
% 
% More info at: http://www.inro.tno.nl/five/traflow/

fprintf('Adding paths for TraFlow and MMFVPDES...\n');
addLocal(['work']);
addLocal(['traflow',filesep,'visualization']);
addLocal(['traflow',filesep,'helpers']);
addLocal(['traflow']);
addLocal(['solver',filesep,'visualization',filesep,'colormaps']);
addLocal(['solver',filesep,'visualization']);
addLocal(['solver',filesep,'helpers']);
addLocal(['solver']);
addLocal(['']);


%%%%
function addLocal(lp)
ap = [pwd,filesep,lp];
addpath(ap);
%fprintf('  ''%s'' added to path.\n', ap);
printf("  '%s' added to path.\n", ap);   %Octave uses a different notation

%There is passed only one argument when addpath is called. That is why 
%va_arg doesn't have to be used in this function.
 
function addpath(path)
  p = path;
  app = 0 ;			# Append? Default is 'no'.
    if strcmp(p,"-end") | strcmp(p,"-END") ,
      app = 1 ;
    elseif strcmp(p,"-begin") | strcmp(p,"-BEGIN") ,
      app = 0 ;
    else
      pp = p ;
      ## Not needed
      ## while rindex(pp,"/") == size(pp,2), pp = pp(1:size(pp,2)-1) ; end
      [s,err,m] = stat(pp) ;		# Check for existence
      if err,
	printf("addpath : Stat on %s returns\n %s\n",pp,m);
      elseif index(s.modestr,"d")!=1,
	printf("addpath : >%s< is not a dir (mode=%s)\n",pp, s.modestr);

      elseif  index(s.modestr,"r")!=2, # Asume I'm owner. That's a bug

	printf("addpath : >%s< is not a readable (mode=%s)\n",...
	       pp,s.modestr);
      elseif ! app,
	LOADPATH = [p,':',LOADPATH] ;
      else
	LOADPATH = [LOADPATH,':',p] ;
      end
    end
  
%function addpath(varargin)
%  app = 0 ;			# Append? Default is 'no'.
%  while nargin--,
%    p = va_arg() ;
%    if strcmp(p,"-end") | strcmp(p,"-END") ,
%      app = 1 ;
%    elseif strcmp(p,"-begin") | strcmp(p,"-BEGIN") ,
%      app = 0 ;
%    else
%      pp = p ;
%      ## Not needed
%      ## while rindex(pp,"/") == size(pp,2), pp = pp(1:size(pp,2)-1) ; end
%      [s,err,m] = stat(pp) ;		# Check for existence
%      if err,
%	printf("addpath : Stat on %s returns\n %s\n",pp,m);
%      elseif index(s.modestr,"d")!=1,
%	printf("addpath : >%s< is not a dir (mode=%s)\n",pp, s.modestr);

%      elseif  index(s.modestr,"r")!=2, # Asume I'm owner. That's a bug

%	printf("addpath : >%s< is not a readable (mode=%s)\n",...
%	       pp,s.modestr);
%      elseif ! app,
%	LOADPATH = [p,':',LOADPATH] ;
%      else
%	LOADPATH = [LOADPATH,':',p] ;
%      end
%    end
%  end
